# muax
A library using Jax that provides help for using DeepMind's mctx on gym-style environments. 
